## Running in a Virtual Machine (VM)

It is recommended to use Kali Linux VM for the lab.

- **Run everything inside one VM** — Docker, Node.js, browser, and Burp Suite (or ZAP) all on the same VM. Then all URLs (`localhost:4280`, `localhost:8000`, `127.0.0.1:8080`) work without changes.
- **VM resources:** Allocate at least **4 GB RAM**, **2 CPU cores**, and **20 GB disk** so Docker (DVWA + WebGoat + MariaDB) and the proxy run smoothly.
- **Snapshots:** Take a VM snapshot after installing Docker and Node.js (before `docker compose up`). You can reset to that state if something breaks or for a clean rerun.

>**WARNING**: **If you split host and VM:** For example, Docker on the host and browser in the VM (or the opposite), replace `localhost` in the README with the IP of the machine where each service runs (e.g. the host’s IP from the VM, or the VM’s IP from the host). You may need to allow the proxy and cookie logger ports (8080, 8000) through the VM network/firewall. Also Burpsuite/ZAP **must** be on the same host with the browser.

## Quick Reference

| Task | Command / URL |
|---|---|
| Start lab | `docker compose up -d` |
| View logs | `docker compose logs -f` |
| Stop lab | `docker compose down` |
| Reset DVWA | `docker compose down -v` |
| DVWA | http://localhost:4280 · `admin` / `password` |
| DVWA setup (first time) | http://localhost:4280/setup.php |
| WebGoat | http://localhost:8090/WebGoat |
| Start cookie logger | `node cookie_logger.js` |
| Cookie logger listens on | http://localhost:8000 |
| Burp proxy | `127.0.0.1:8080` |


## Installing Docker and Node.js (first-time setup)

If you have never installed Docker or Node.js, install them **before** starting the lab. Check that they work by running `docker --version` and `node --version` (Node.js v22 or higher required).

- **Docker:** [Install Docker](https://docs.docker.com/get-docker/) — official install guide for all platforms. [Docker troubleshooting](https://docs.docker.com/desktop/troubleshoot/overview/).
- **Node.js:** [Install Node.js](https://nodejs.org/en/download/) — official downloads and install instructions. [Troubleshooting Node.js](https://nodejs.org/en/docs/guides/troubleshooting/).

When both commands succeed, continue with [Step 1: Start the Lab Containers](README.md#step-1-start-the-lab-containers).

